package com.company;

import com.company.manage.StockEntityManager;
import com.company.model.StockEnum;
import com.company.model.Trade;
import com.company.services.StockService;
import com.company.stocks.Spring;
import com.company.stocks.SuperSimpleStockFactory;


import org.apache.log4j.Logger;
import org.junit.Test;
import java.util.ArrayList;
import org.junit.Assert;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by Zem Imane on 29/09/2016.
 */

@ContextConfiguration(locations = {"classpath:resources/appContext.xml"})
public class SuperSimpleStockFactoryTest {


    protected static ApplicationContext context;

        Logger logger = Logger.getLogger("SuperSimpleStockFactoryTest.class");


        @Test
        public void isStockServicesFactoryASingleton(){
            logger.info("DEBUT isStockServicesFactoryASingleton ...");
            SuperSimpleStockFactory factoryInstanceA = SuperSimpleStockFactory.INSTANCE;
            SuperSimpleStockFactory factoryInstanceB = SuperSimpleStockFactory.INSTANCE;
            Assert.assertNotNull(factoryInstanceA);
            Assert.assertNotNull(factoryInstanceB);
            Assert.assertTrue(factoryInstanceA.equals(factoryInstanceB));
            logger.info("FIN isStockServicesFactoryASingleton ");
        }


        @Test
        public void isStockServicesASingleton(){
            logger.info("DEBUT isStockServicesASingleton ...");
            SuperSimpleStockFactory factoryInstance = SuperSimpleStockFactory.INSTANCE;
            StockService StockServiceA = factoryInstance.getStockService();
            StockService StockServiceB = factoryInstance.getStockService();
            Assert.assertNotNull(StockServiceA);
            Assert.assertNotNull(StockServiceB);
            Assert.assertTrue(StockServiceA.equals(StockServiceB));
            logger.info("FIN isStockServicesASingleton ");
        }

        @Test
        public void recordATradeTest(){
            logger.info("DEBUT recordATradeTest ...");
// Create the stock service and verify it's not null object
            StockService StockService = SuperSimpleStockFactory.INSTANCE.getStockService();
            Assert.assertNotNull(StockService);
// Recover the trades configured in spring for the unit test
            @SuppressWarnings("unchecked")
            ArrayList<Trade> tradeList = Spring.INSTANCE.getBean("tradeList", ArrayList.class);
            Assert.assertNotNull(tradeList);
            logger.info("Trade List size: "+tradeList.size());
            try{
// Initial trades are empty, means, trades number equls to cero (0)
                StockEntityManager stockEntityManager = Spring.INSTANCE.getBean("stockEntityManager", StockEntityManager.class);
                int tradesNumber = stockEntityManager.getTrades().size();
                logger.info("Trades number: "+tradesNumber);
                Assert.assertEquals(tradesNumber, 0);
// Insert many trades in the stock system
                for(Trade trade: tradeList){
                    boolean result = StockService.recordTrade(trade);
                    Assert.assertTrue(result);
                }
// After record trades, the number of trades should be equal to the trades list
                tradesNumber = stockEntityManager.getTrades().size();
                logger.info("Trades number: "+tradesNumber);
                Assert.assertEquals(tradesNumber, tradeList.size());
            }catch(Exception exception){
                logger.error(exception);
                Assert.assertTrue(false);
            }
            logger.info("FIN recordATradeTest");
        }
        @Test
        public void calculateDividendYieldTest(){
            logger.info("DEBUT calculateDividendYieldTest ...");
            try{
// Create the stock service and verify it's not null object
                StockService StockService = SuperSimpleStockFactory.INSTANCE.getStockService();
                Assert.assertNotNull(StockService);
                StockEntityManager stockEntityManager = Spring.INSTANCE.getBean("stockEntityManager", StockEntityManager.class);
                int tradesNumber = stockEntityManager.getTrades().size();
                logger.info("Trades number: "+tradesNumber);
// Calculates the dividend yield for the stock symbol
                String[] stockSymbols = {"TEA", "POP", "ALE", "GIN", "JOE"};
//String[] stockSymbols = {"TEA"};
                for(String stockSymbol: stockSymbols){
                    double dividendYield = StockService.calculateDividendYield(stockSymbol);
                    logger.info(stockSymbol+" - DividendYield calculated: "+dividendYield);
                    Assert.assertTrue(dividendYield >= 0.0);
                }
            }catch(Exception exception){
                logger.error(exception);
                Assert.assertTrue(false);
            }
            logger.info("FIN calculateDividendYieldTest ");
        }
        @Test
        public void calculatePERatioTest(){
            logger.info("DEBUT calculatePERatioTest ...");
            try{
// Create the stock service and verify it's not null object
                StockService StockService = SuperSimpleStockFactory.INSTANCE.getStockService();
                Assert.assertNotNull(StockService);
                StockEntityManager stockEntityManager = Spring.INSTANCE.getBean("stockEntityManager", StockEntityManager.class);
                int tradesNumber = stockEntityManager.getTrades().size();
                logger.info("Trades number: "+tradesNumber);
// Calculates the P/E Ratio for the stock Symbol
                String[] stockSymbols = {"TEA", "POP", "ALE", "GIN", "JOE"};
//String[] stockSymbols = {"TEA"};
                for(String stockSymbol: stockSymbols){
                    double peRatio = StockService.calculatePERatio(stockSymbol);
                    logger.info(stockSymbol+" - P/E Ratio calculated: "+peRatio);
                    Assert.assertTrue(peRatio >= 0.0);
                }
            }catch(Exception exception){
                logger.error(exception);
                Assert.assertTrue(false);
            }
            logger.info("FIN calculatePERatioTest ");
        }
        /**
         *
         */
        @Test
        public void calculateStockPriceTest(){
            try{
// Create the stock service and verify it's not null object
                StockService StockService = SuperSimpleStockFactory.INSTANCE.getStockService();
                Assert.assertNotNull(StockService);
                StockEntityManager stockEntityManager = Spring.INSTANCE.getBean("stockEntityManager", StockEntityManager.class);
                int tradesNumber = stockEntityManager.getTrades().size();
                logger.info("Trades number: "+tradesNumber);
// Calculates the Stock Price for all stocks
                String[] stockSymbols = {"TEA", "POP", "ALE", "GIN", "JOE"};
//String[] stockSymbols = {"TEA"};
                for(String stockSymbol: stockSymbols){
                    double stockPrice = StockService.calculateStockPrice(stockSymbol);
                    logger.info(stockSymbol+" - Stock Price calculated: "+stockPrice);
                    Assert.assertTrue(stockPrice >= 0.0);
                }
            }catch(Exception exception){
                logger.error(exception);
                Assert.assertTrue(false);
            }
        }
        /**
         *
         */
        @Test
        public void calculateGBCEAllShareIndexTest(){
            try{
// Create the stock service and verify it's not null object
                StockService StockService = SuperSimpleStockFactory.INSTANCE.getStockService();
                Assert.assertNotNull(StockService);
                StockEntityManager stockEntityManager = Spring.INSTANCE.getBean("stockEntityManager", StockEntityManager.class);
                int tradesNumber = stockEntityManager.getTrades().size();
                logger.info("Trades number: "+tradesNumber);
                double GBCEAllShareIndex = StockService.calculateGBCEAllShareIndex();
                logger.info("GBCE All Share Index: "+GBCEAllShareIndex);
                Assert.assertTrue(GBCEAllShareIndex > 0.0);
            }catch(Exception exception){
                logger.error(exception);
                Assert.assertTrue(false);
            }
        }
}
