package com.company.model;

/**
 * Constants for the buy or sel indicator associated to a trade in the Simple Stocks application.
 * Created by Zem Imane on 29/09/2016.
 */
public enum TradeEnum {

    /**
     * Indicates that a trade represents a BUY of shares for an specific stock.
     */
    BUY,
/**
 * Indicates that a trade represents a SELL of shares for an specific stock.
 */
    SELL

}
