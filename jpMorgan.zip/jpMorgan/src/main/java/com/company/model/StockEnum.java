package com.company.model;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Constants for the stock type available in the Simple Stocks application.
 * Created by Zem Imane on 29/09/2016.
 */

public enum StockEnum {


    /**
         * Indicates that a stock is common and the dividend yield is calculated with last dividend.
         */
        COMMON,
        /**
         * Indicates that a stock is preferred and the dividend yield is calculated with fixed dividend.
         */
        PREFERRED;


    StockEnum() {
    }
}


