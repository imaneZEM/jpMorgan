package com.company.manage.impl;

import com.company.manage.StockEntityManager;
import com.company.model.Stock;
import com.company.model.Trade;

import java.util.ArrayList;
import java.util.HashMap;
import org.apache.log4j.Logger;

/**
 * Created by Zem Imane on 29/09/2016.
 */
public class StockEntityManageImpl implements StockEntityManager {

    /**
     *
     */
    private Logger logger = Logger.getLogger("StockEntityManageImpl.class");
    /**
     *
     */
    private HashMap<String, Stock> stocks = null;
    /**
     *
     */
    private ArrayList<Trade> trades = null;
    /**
     *
     */
    public StockEntityManageImpl(){
        trades = new ArrayList<Trade>();
        stocks = new HashMap<String, Stock>();
    }
    /*
    * (non-Javadoc)
    * @see com.company.manage.StockEntityManager#getStocks()
    */
    public HashMap<String, Stock> getStocks() {
        return stocks;
    }
    /**
     *
     * @param stocks
     */
    public void setStocks(HashMap<String, Stock> stocks) {
        this.stocks = stocks;
    }
    /*
    * (non-Javadoc)
    * @see com.company.manage.StockEntityManager#getTrades()
    */
    public ArrayList<Trade> getTrades() {
        return trades;
    }
    /**
     *
     * @param trades
     */
    public void setTrades(ArrayList<Trade> trades) {
        this.trades = trades;
    }
    /*
    * (non-Javadoc)
    * @see com.company.manage.StockEntityManager#recordTrade(com.company.model.Trade)
    */
    public boolean recordTrade(Trade trade) throws Exception{
        boolean result = false;
        try{
            result = trades.add(trade);
        }catch(Exception exception){
            throw new Exception("Une erreur s'est produite.", exception);
        }
        return result;
    }
    /*
    * (non-Javadoc)
    * @see com.company.manage.StockEntityManager#getTradesNumber()
    */
    public int getTradesNumber() {
        return trades.size();
    }
    /*
    * (non-Javadoc)
    * @see com.company.manage.StockEntityManager#getStockBySymbol(java.lang.String)
    */
    public Stock getStockBySymbol(String stockSymbol){
        Stock stock = null;
        try{
            if(stockSymbol!=null){
                stock = stocks.get(stockSymbol);
            }
        }catch(Exception exception){
            logger.error("Une erreur s'est produite lors de l'enregistrement du stock objet pour le stock symbol: "+stockSymbol+".", exception);
        }
        return stock;
    }

}
