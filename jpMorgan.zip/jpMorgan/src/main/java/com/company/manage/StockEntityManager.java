package com.company.manage;

import com.company.model.Stock;
import com.company.model.Trade;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Zem Imane on 29/09/2016.
 */
public interface  StockEntityManager {

    public boolean recordTrade(Trade trade) throws Exception;
    /**
     * Gets the array list that contains all the trades.
     *
     * @return The array list that contains all the trades in the Super Simple Stocks application.
     */
    public ArrayList<Trade> getTrades();
    /**
     *
     * @param stockSymbol
     * @return
     */
    public Stock getStockBySymbol(String stockSymbol);
    /**
     * Gets all the stocks supported by Super Simple Stocks application.
     *
     * @return The hash map that contains all the stocks supported by the Super Simple Stocks application.
     */
    public HashMap<String, Stock> getStocks();


}
