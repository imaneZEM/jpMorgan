package com.company.stocks;

import com.company.model.Trade;
import com.company.services.StockService;
import com.company.stocks.impl.SuperSimpleStockFactoryImpl;

/**
 * Created by Zem Imane on 29/09/2016.
 *Super Simple Service, which implements the five operations to calculate the dividend yield,
 * P/E Ratio, Stock Price, GBCE All Share Index and record trades for a given stock.
 */
public interface SuperSimpleStockFactory {


    /**
     * Singleton instance of the factory StockServicesFactory.
     */

    public SuperSimpleStockFactory INSTANCE = SuperSimpleStockFactoryImpl.getInstance();

    /**
     * Gets the singleton instance of the Super Simple Service, which implements the five operations
     * to calculate the dividend yield, P/E Ratio, Stock Price, GBCE All Share Index and record trades
     * for a given stock.
     *
     * @return An object of type StockService, representing a instance of the Super Simple Service
     */

    public StockService getStockService();


    }

