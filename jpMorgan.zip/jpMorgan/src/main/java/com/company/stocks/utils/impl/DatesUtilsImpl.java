package com.company.stocks.utils.impl;


import com.company.stocks.utils.DatesUtils;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by Zem Imane on 29/09/2016.
 */
public class DatesUtilsImpl implements DatesUtils {
        /**
         * Constructor of the class.
         */
        public DatesUtilsImpl(){
        }

        public Date getNowMovedMinutes(int minutes){
            Calendar now = Calendar.getInstance();
            now.add(Calendar.MINUTE, minutes);
            return now.getTime();
        }

}
