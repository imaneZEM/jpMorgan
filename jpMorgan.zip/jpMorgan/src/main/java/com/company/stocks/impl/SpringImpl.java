package com.company.stocks.impl;

import com.company.stocks.Spring;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.logging.Logger;

/**
 * Created by Zem Imane on 29/09/2016.
 */
public class SpringImpl implements Spring{

    /**
     * Logger service for the class.
     */
    private Logger logger = Logger.getLogger("SpringImpl.class");
    /**
     * Spring context files pattern defined for the Super Simple Stocks application.
     */
    private static final String SPRING_CONTEXT_FILE_NAME = "classpath:testContext.xml";
    /**
     * Spring context object.
     */
    private AbstractApplicationContext springContext = null;
    /**
     * Constructor of the class. The main purpose of the constructor is to load the Spring context for the Super Simple Stocks applicarion.
     */
    private SpringImpl(){
        logger.info("Loading Spring Context for Super Simple Stocks.");
        springContext = new ClassPathXmlApplicationContext(SPRING_CONTEXT_FILE_NAME);
        springContext.registerShutdownHook();
        logger.info("****Spring Context****");
    }
    /**
     * Holder class for the singleton factory instance. {@link SpringHolder} is
     * loaded on the first execution of {@link SpringImpl#getInstance()} or the first
     * access to {@link SpringHolder#INSTANCE}, not before.

     */
    private static class SpringHolder{
        private static final Spring INSTANCE = new SpringImpl();
    }
    /**
     * Gets the singleton instance of the spring services.
     *
     * @return An object of the SpringService, which represents the service to access to all
     * beans in the spring container.
     */
    public static Spring getInstance(){
        return SpringHolder.INSTANCE;
    }
    /*
    * (non-Javadoc)
    * @see com.company.stocks.Spring#getBean(java.lang.String, java.lang.Class)
    */
    public <T> T getBean(String beanName, Class<T> objectClass) {
        return springContext.getBean(beanName, objectClass);
    }
    /*
    * (non-Javadoc)
    * @see com.company.stocks.Spring#getBean(java.lang.Class)
    */
    public <T> T getBean(Class<T> objectClass) {
        return springContext.getBean(objectClass);
    }


}
