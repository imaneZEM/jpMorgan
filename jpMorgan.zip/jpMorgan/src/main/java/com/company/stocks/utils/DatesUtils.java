package com.company.stocks.utils;

import java.util.Date;

/**
 * Created by Zem Imane on 29/09/2016.
 */
public interface DatesUtils {

    public Date getNowMovedMinutes(int minutes);

}
