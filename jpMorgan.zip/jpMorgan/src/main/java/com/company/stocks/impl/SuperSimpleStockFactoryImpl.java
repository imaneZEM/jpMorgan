package com.company.stocks.impl;

import com.company.services.StockService;
import com.company.stocks.Spring;
import com.company.stocks.SuperSimpleStockFactory;

/**
 * Created by Zem Imane on 29/09/2016.
 */
public class SuperSimpleStockFactoryImpl implements SuperSimpleStockFactory {

    /**
     * Private constructor for the factory which prevents new instance
     */
    private SuperSimpleStockFactoryImpl(){
/**
 * 1. Load the spring context for the engine
 */
        Spring.INSTANCE.getClass();
    }
    /**
     * Holder class for the singleton factory instance. {@link StockServicesFactoryHolder} is
     * loaded on the first execution of {@link SuperSimpleStockFactoryImpl#getInstance()} or the first
     * access to {@link StockServicesFactoryHolder#INSTANCE}, not before.
     *

     */
    private static class StockServicesFactoryHolder{
        private static final SuperSimpleStockFactory INSTANCE = new SuperSimpleStockFactoryImpl();
    }
    /**
     * Gets the singleton instance of the factory of the services in the Super Simple Stock application.
     *
     * @return An object of the SimpleStockServicesFactory, which represents the factory to access to all
     * services in the Super Simple Stock application.
     */
    public static SuperSimpleStockFactory getInstance(){
        return StockServicesFactoryHolder.INSTANCE;
    }
    /*

    */
    public StockService getStockService(){
        return Spring.INSTANCE.getBean("stockService", StockService.class);
    }




}
