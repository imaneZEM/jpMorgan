package com.company.services;

import com.company.model.Trade;

/**
 * Created by Zem Imane on 29/09/2016.
 */
public interface StockService {

    /**
     * Calculates the dividend yield for a given stock.
     *
     * @param stockSymbol Stock symbol.
     *
     * @return A double value which represents the dividend yield for a given stock.
     *
     * @throws Exception A exception raised during the execution of the method due to an error.
     */
    public double calculateDividendYield(String stockSymbol) throws Exception;
    /**
     * Calculates the P/E Ratio for a given stock.
     *
     * @param stockSymbol Stock symbol.
     *
     * @return A double value which represents the P/E Ratio for a given stock.
     *
     * @throws Exception A exception raised during the execution of the method due to an error.
     */
    public double calculatePERatio(String stockSymbol) throws Exception;
    /**
     * Record a trade in the Super Simple Stocks application.
     *
     * @param trade Trade object to record.
     *
     * @return True, when the record is successful. Other case, False.
     */
    public boolean recordTrade(Trade trade) throws Exception;
    /**
     *
     * @param stockSymbol
     * @return
     * @throws Exception
     */
    public double calculateStockPrice(String stockSymbol) throws Exception;
    /**
     *
     * @return
     * @throws Exception
     */
    public double calculateGBCEAllShareIndex() throws Exception;


}
